import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = parseInt(process.env.PORT || '3000', 10);

// Increase JSON limit to handle camera frames in base64
app.use(express.json({ limit: '15mb' }));

// -----------------------------------------------------------------------------
// 1. Roboflow Server-Side Inference Proxy
// -----------------------------------------------------------------------------
app.post('/api/infer-sign', async (req: Request, res: Response) => {
  try {
    const { image, threshold } = req.body;

    if (!image || typeof image !== 'string') {
      return res.status(400).json({
        error: 'Invalid request: base64 image payload is required.',
      });
    }

    const apiKey = process.env.ROBOFLOW_API_KEY;
    const modelId = process.env.ROBOFLOW_MODEL_ID || 'indian-sign-language-fkx1f-8kfux/1';
    const confidenceThreshold =
      typeof threshold === 'number'
        ? threshold
        : parseFloat(process.env.ROBOFLOW_CONFIDENCE_THRESHOLD || '0.50');

    if (!apiKey || apiKey === 'your_roboflow_api_key_here') {
      return res.status(503).json({
        error: 'Roboflow API key is not configured on the backend server.',
        unconfigured: true,
      });
    }

    // Clean base64 string (strip data:image/...;base64, prefix if present)
    const base64Data = image.replace(/^data:image\/[a-z]+;base64,/, '');

    // Pass confidence=15 to Roboflow so it doesn't aggressively filter candidate bounding boxes upstream
    const roboflowUrl = `https://serverless.roboflow.com/${modelId}?confidence=15`;
    const roboflowResponse = await fetch(roboflowUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: base64Data,
    });

    if (!roboflowResponse.ok) {
      const errorText = await roboflowResponse.text();
      let parsedError: Record<string, unknown> = {};
      try {
        parsedError = JSON.parse(errorText);
      } catch {
        parsedError = { raw: errorText };
      }

      console.error('Roboflow API error:', roboflowResponse.status, parsedError);
      return res.status(502).json({
        error: 'Roboflow server inference failed.',
        details: parsedError.message || 'Upstream provider returned an error.',
      });
    }

    const data = await roboflowResponse.json();
    const rawPredictions = Array.isArray(data.predictions) ? data.predictions : [];

    // Sort all raw predictions descending by confidence
    rawPredictions.sort((a: { confidence: number }, b: { confidence: number }) => b.confidence - a.confidence);

    // Filter by user's confidence threshold
    const validPredictions = rawPredictions.filter(
      (p: { confidence?: number }) => typeof p.confidence === 'number' && p.confidence >= confidenceThreshold
    );

    const topPrediction = validPredictions[0] || null;
    const bestCandidate = rawPredictions[0] || null;

    const ALL_32_CLASSES = [
      'Bad', 'Brother', 'Father', 'Food', 'Friend', 'Good', 'Hello', 'Help',
      'House', 'I', 'Indian', 'Loud', 'Mummy', 'Namaste', 'Name', 'No',
      'Place', 'Please', 'Quiet', 'Sleeping', 'Sorry', 'Strong', 'Thank-you',
      'Time', 'Today', 'Water', 'What', 'Yes', 'Your', 'language', 'sign', 'you'
    ];

    return res.json({
      success: true,
      model: modelId,
      thresholdApplied: confidenceThreshold,
      totalPredictions: rawPredictions.length,
      supportedClasses: ALL_32_CLASSES,
      topPrediction: topPrediction
        ? {
            class: topPrediction.class,
            confidence: topPrediction.confidence,
            bbox: {
              x: topPrediction.x,
              y: topPrediction.y,
              width: topPrediction.width,
              height: topPrediction.height,
            },
          }
        : null,
      bestCandidate:
        !topPrediction && bestCandidate
          ? {
              class: bestCandidate.class,
              confidence: bestCandidate.confidence,
              bbox: {
                x: bestCandidate.x,
                y: bestCandidate.y,
                width: bestCandidate.width,
                height: bestCandidate.height,
              },
            }
          : null,
      imageDimensions: data.image || null,
    });
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : 'Unknown inference error';
    console.error('Error in /api/infer-sign:', errorMsg);
    return res.status(500).json({
      error: 'Internal server error during sign inference.',
      details: errorMsg,
    });
  }
});

// -----------------------------------------------------------------------------
// 2. Emergency SOS Notification Endpoint
// -----------------------------------------------------------------------------
app.post('/api/sos', async (req: Request, res: Response) => {
  try {
    const { clientTimestamp, note } = req.body;

    const webhookUrl = process.env.SOS_NOTIFICATION_WEBHOOK_URL;
    const recipientPhone = process.env.SOS_RECIPIENT_PHONE;
    const twilioSid = process.env.TWILIO_ACCOUNT_SID;
    const twilioAuth = process.env.TWILIO_AUTH_TOKEN;
    const twilioFrom = process.env.TWILIO_FROM_PHONE;
    const emergencyMessage =
      process.env.SOS_CUSTOM_MESSAGE ||
      'EMERGENCY ALERT: An ISL user using SAMVAAD has triggered an SOS alert.';

    const hotlineContacts = [
      { name: 'National Emergency Helpline (India)', number: '112', type: 'All-in-one Emergency' },
      { name: 'Police', number: '100', type: 'Police Assistance' },
      { name: 'Ambulance & Medical Emergency', number: '108', type: 'Medical' },
      { name: 'Women Helpline', number: '1091', type: 'Women Safety' },
      { name: 'Disaster Management', number: '1077', type: 'Disaster Response' },
    ];

    // If no notification channel is configured
    const isConfigured = Boolean(webhookUrl || (twilioSid && twilioAuth && twilioFrom && recipientPhone));

    if (!isConfigured) {
      return res.status(200).json({
        success: false,
        configured: false,
        status: 'unconfigured',
        message: 'No automated notification provider is configured in the backend environment.',
        advice: 'Please use direct emergency call numbers immediately.',
        emergencyHotlines: hotlineContacts,
      });
    }

    // Dispatch via Webhook if configured
    if (webhookUrl) {
      try {
        const webhookRes = await fetch(webhookUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            event: 'SOS_TRIGGERED',
            source: 'SAMVAAD_ISL_APP',
            timestamp: clientTimestamp || new Date().toISOString(),
            note: note || emergencyMessage,
          }),
        });

        if (!webhookRes.ok) {
          throw new Error(`Webhook responded with status ${webhookRes.status}`);
        }

        return res.json({
          success: true,
          configured: true,
          status: 'dispatched',
          provider: 'webhook',
          message: 'Emergency notification was accepted by the emergency webhook.',
          emergencyHotlines: hotlineContacts,
        });
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : 'Webhook error';
        console.error('Failed to trigger SOS webhook:', msg);
        return res.status(502).json({
          success: false,
          configured: true,
          status: 'failed',
          error: 'Failed to deliver notification to emergency webhook.',
          details: msg,
          emergencyHotlines: hotlineContacts,
        });
      }
    }

    // Dispatch via Twilio SMS if configured
    if (twilioSid && twilioAuth && twilioFrom && recipientPhone) {
      try {
        const twilioUrl = `https://api.twilio.com/2010-04-01/Accounts/${twilioSid}/Messages.json`;
        const params = new URLSearchParams();
        params.append('To', recipientPhone);
        params.append('From', twilioFrom);
        params.append('Body', `${emergencyMessage} Time: ${clientTimestamp || new Date().toLocaleTimeString()}`);

        const twilioRes = await fetch(twilioUrl, {
          method: 'POST',
          headers: {
            'Authorization': 'Basic ' + Buffer.from(`${twilioSid}:${twilioAuth}`).toString('base64'),
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: params.toString(),
        });

        if (!twilioRes.ok) {
          const errData = await twilioRes.text();
          throw new Error(`Twilio error: ${errData}`);
        }

        return res.json({
          success: true,
          configured: true,
          status: 'dispatched',
          provider: 'sms',
          recipient: recipientPhone.replace(/.(?=.{4})/g, '*'), // Mask phone for safety
          message: 'Emergency SMS notification was accepted by the SMS provider.',
          emergencyHotlines: hotlineContacts,
        });
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : 'SMS dispatch error';
        console.error('Failed to send SOS SMS:', msg);
        return res.status(502).json({
          success: false,
          configured: true,
          status: 'failed',
          error: 'Emergency SMS dispatch failed at provider.',
          details: msg,
          emergencyHotlines: hotlineContacts,
        });
      }
    }

    return res.status(500).json({
      success: false,
      error: 'Unexpected configuration state.',
      emergencyHotlines: hotlineContacts,
    });
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : 'Internal error';
    return res.status(500).json({
      error: 'Internal server error while processing emergency request.',
      details: errorMsg,
    });
  }
});

// -----------------------------------------------------------------------------
// 3. System Status / Health
// -----------------------------------------------------------------------------
app.get('/api/status', (_req: Request, res: Response) => {
  const hasRoboflowKey = Boolean(
    process.env.ROBOFLOW_API_KEY &&
    process.env.ROBOFLOW_API_KEY !== 'your_roboflow_api_key_here'
  );
  const hasSosConfigured = Boolean(
    process.env.SOS_NOTIFICATION_WEBHOOK_URL ||
    (process.env.TWILIO_ACCOUNT_SID && process.env.SOS_RECIPIENT_PHONE)
  );

  res.json({
    app: 'SAMVAAD',
    roboflowConfigured: hasRoboflowKey,
    roboflowModel: process.env.ROBOFLOW_MODEL_ID || 'indian-sign-language-fkx1f-8kfux/1',
    sosConfigured: hasSosConfigured,
    timestamp: new Date().toISOString(),
  });
});

// -----------------------------------------------------------------------------
// 4. Vite Middlewares (Dev) or Static Assets (Prod)
// -----------------------------------------------------------------------------
async function setupVite() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`[SAMVAAD] Full-stack server running on http://0.0.0.0:${port}`);
  });
}

setupVite();
