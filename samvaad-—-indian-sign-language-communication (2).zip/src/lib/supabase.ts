import { createClient } from '@supabase/supabase-js';
import type { IslVideo } from '../types';

const supabaseUrl =
  import.meta.env.VITE_SUPABASE_URL || 'https://cdnnjivtfzzfihgzlzys.supabase.co';
const supabaseAnonKey =
  import.meta.env.VITE_SUPABASE_ANON_KEY || 'sb_publishable_uAAxbb4qw3gqfWPztm8DiQ_VCWcg4un';

/**
 * Shared Supabase Client
 * Initialized once and reused across the application
 */
export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface SearchMatchResult {
  match: IslVideo | null;
  matchType: 'exact' | 'keyword' | null;
  matchedTerm?: string;
  isPartialSentence?: boolean;
  untranslatedTerms?: string[];
  error?: string;
}

/**
 * Queries Supabase for genuine, verified ISL sign videos.
 * Never returns unverified records (enforced by RLS and client filter).
 */
export async function findVerifiedSignVideo(rawQuery: string): Promise<SearchMatchResult> {
  const query = rawQuery.trim().toLowerCase();
  if (!query) {
    return { match: null, matchType: null };
  }

  try {
    // 1. Attempt exact case-insensitive phrase match first
    const { data: exactData, error: exactError } = await supabase
      .from('isl_videos')
      .select('*')
      .eq('is_verified', true)
      .ilike('phrase', query)
      .limit(1);

    if (exactError) {
      console.warn('Supabase exact match query error:', exactError.message);
      return { match: null, matchType: null, error: exactError.message };
    }

    if (exactData && exactData.length > 0) {
      return {
        match: exactData[0] as IslVideo,
        matchType: 'exact',
        matchedTerm: exactData[0].phrase,
      };
    }

    // 2. Attempt keyword array match for the full phrase
    const { data: keywordData, error: keywordError } = await supabase
      .from('isl_videos')
      .select('*')
      .eq('is_verified', true)
      .contains('keywords', [query])
      .limit(1);

    if (keywordError) {
      console.warn('Supabase keyword query error:', keywordError.message);
    }

    if (keywordData && keywordData.length > 0) {
      return {
        match: keywordData[0] as IslVideo,
        matchType: 'keyword',
        matchedTerm: keywordData[0].phrase,
      };
    }

    // 3. For multi-word sentences, check if key words match verified signs.
    // As per specifications: do NOT claim fluent grammar translation.
    // Clearly flag if only a single keyword matched out of a sentence.
    const words = query
      .replace(/[^\w\s]/gi, '')
      .split(/\s+/)
      .filter((w) => w.length > 1);

    if (words.length > 1) {
      for (const word of words) {
        const { data: wordData } = await supabase
          .from('isl_videos')
          .select('*')
          .eq('is_verified', true)
          .or(`phrase.ilike.${word},keywords.cs.{${word}}`)
          .limit(1);

        if (wordData && wordData.length > 0) {
          const untranslated = words.filter((w) => w !== word);
          return {
            match: wordData[0] as IslVideo,
            matchType: 'keyword',
            matchedTerm: wordData[0].phrase,
            isPartialSentence: true,
            untranslatedTerms: untranslated,
          };
        }
      }
    }

    // No verified match found
    return { match: null, matchType: null };
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Database query failed';
    return { match: null, matchType: null, error: message };
  }
}

/**
 * Fetch all verified sign records for the index list
 */
export async function getVerifiedSignList(): Promise<IslVideo[]> {
  try {
    const { data, error } = await supabase
      .from('isl_videos')
      .select('*')
      .eq('is_verified', true)
      .order('phrase', { ascending: true });

    if (error) {
      console.warn('Could not fetch verified sign list:', error.message);
      return [];
    }
    return (data as IslVideo[]) || [];
  } catch (err) {
    console.warn('Error fetching verified videos:', err);
    return [];
  }
}
