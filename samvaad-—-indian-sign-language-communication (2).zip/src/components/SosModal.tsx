import React, { useState } from 'react';
import {
  ShieldAlert,
  AlertTriangle,
  Phone,
  CheckCircle2,
  XCircle,
  Loader2,
  X,
  ExternalLink,
  Info,
} from 'lucide-react';
import type { SosResponse } from '../types';

interface SosModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SosModal: React.FC<SosModalProps> = ({ isOpen, onClose }) => {
  const [step, setStep] = useState<'confirm' | 'sending' | 'result'>('confirm');
  const [sosResult, setSosResult] = useState<SosResponse | null>(null);

  if (!isOpen) return null;

  const handleSendSos = async () => {
    setStep('sending');
    try {
      const response = await fetch('/api/sos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          clientTimestamp: new Date().toISOString(),
          note: 'Emergency distress signal initiated from SAMVAAD web client.',
        }),
      });

      const data: SosResponse = await response.json();
      setSosResult(data);
      setStep('result');
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Network request failed';
      setSosResult({
        success: false,
        configured: false,
        status: 'failed',
        message: 'Could not contact backend emergency dispatch service.',
        error: message,
        emergencyHotlines: [
          { name: 'National Emergency Helpline (India)', number: '112', type: 'All-in-one Emergency' },
          { name: 'Police', number: '100', type: 'Police Assistance' },
          { name: 'Ambulance & Medical Emergency', number: '108', type: 'Medical' },
          { name: 'Women Helpline', number: '1091', type: 'Women Safety' },
        ],
      });
      setStep('result');
    }
  };

  const handleReset = () => {
    setStep('confirm');
    setSosResult(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="bg-rose-50 border-b border-rose-100 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5 text-rose-700">
            <ShieldAlert className="w-5 h-5 text-rose-600" />
            <h2 className="font-bold text-base tracking-tight">Emergency SOS Dispatch</h2>
          </div>
          <button
            onClick={handleReset}
            className="p-1 rounded-md text-slate-400 hover:text-slate-700 hover:bg-rose-100/60 transition-colors"
            aria-label="Close SOS Modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content based on step */}
        <div className="p-6">
          {step === 'confirm' && (
            <div className="space-y-4">
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div className="space-y-1 text-xs text-amber-900 leading-relaxed">
                  <p className="font-bold text-sm text-amber-950">
                    Confirm Emergency Notification
                  </p>
                  <p>
                    This will transmit an urgent emergency alert containing your current timestamp to your configured emergency contact, webhook, or SMS provider.
                  </p>
                  <p className="text-amber-800">
                    Please only activate this in situations requiring genuine urgent assistance.
                  </p>
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  onClick={handleReset}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSendSos}
                  className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 active:bg-rose-800 text-white font-bold text-xs sm:text-sm rounded-lg shadow-sm transition-colors flex items-center gap-2"
                >
                  <ShieldAlert className="w-4 h-4" />
                  <span>Send SOS Alert Now</span>
                </button>
              </div>
            </div>
          )}

          {step === 'sending' && (
            <div className="py-8 text-center space-y-4">
              <Loader2 className="w-10 h-10 text-rose-600 animate-spin mx-auto" />
              <div className="space-y-1">
                <h3 className="text-base font-bold text-slate-900">
                  Contacting Emergency Dispatch Channel...
                </h3>
                <p className="text-xs text-slate-500">
                  Sending alert payload through secure backend service.
                </p>
              </div>
            </div>
          )}

          {step === 'result' && sosResult && (
            <div className="space-y-5">
              {/* Dispatched State */}
              {sosResult.status === 'dispatched' && (
                <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl space-y-2">
                  <div className="flex items-center gap-2 text-emerald-800 font-bold text-sm">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    <span>Notification Accepted by Provider</span>
                  </div>
                  <p className="text-xs text-emerald-900 leading-relaxed">
                    {sosResult.message}
                  </p>
                  <div className="pt-2 border-t border-emerald-200/60 text-[11px] text-emerald-700 space-y-0.5">
                    <p>
                      <strong>Important Notice:</strong> This confirmation indicates the alert was accepted by your notification provider (
                      <span className="font-mono">{sosResult.provider}</span>). Emergency assistance depends on provider routing and real-world responder dispatch.
                    </p>
                  </div>
                </div>
              )}

              {/* Unconfigured Provider State */}
              {sosResult.status === 'unconfigured' && (
                <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl space-y-2">
                  <div className="flex items-center gap-2 text-amber-900 font-bold text-sm">
                    <AlertTriangle className="w-5 h-5 text-amber-600" />
                    <span>No Notification Provider Configured</span>
                  </div>
                  <p className="text-xs text-amber-900 leading-relaxed">
                    Automated alert dispatch was not sent because neither an SOS Webhook nor SMS provider is configured in your backend environment (<code className="font-mono text-amber-950">.env</code>).
                  </p>
                  <p className="text-xs font-semibold text-amber-950">
                    Use the direct manual emergency contact options below:
                  </p>
                </div>
              )}

              {/* Failed State */}
              {sosResult.status === 'failed' && (
                <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl space-y-2">
                  <div className="flex items-center gap-2 text-rose-900 font-bold text-sm">
                    <XCircle className="w-5 h-5 text-rose-600" />
                    <span>Dispatch Failed</span>
                  </div>
                  <p className="text-xs text-rose-900">
                    {sosResult.message || sosResult.error}
                  </p>
                </div>
              )}

              {/* Immediate Manual Emergency Telephone Numbers */}
              <div className="space-y-2">
                <span className="text-xs font-semibold text-slate-700 block">
                  Direct Emergency Hotlines (India):
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {sosResult.emergencyHotlines.map((hotline) => (
                    <a
                      key={hotline.number}
                      href={`tel:${hotline.number}`}
                      className="p-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg flex items-center justify-between transition-colors group"
                    >
                      <div>
                        <p className="text-xs font-bold text-slate-900 group-hover:text-rose-600 transition-colors">
                          {hotline.name}
                        </p>
                        <p className="text-[11px] text-slate-500">{hotline.type}</p>
                      </div>
                      <div className="flex items-center gap-1 bg-white px-2 py-1 rounded border border-slate-200 font-mono text-xs font-bold text-slate-800">
                        <Phone className="w-3 h-3 text-rose-600" />
                        <span>{hotline.number}</span>
                      </div>
                    </a>
                  ))}
                </div>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  onClick={handleReset}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-medium text-xs rounded-lg transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
