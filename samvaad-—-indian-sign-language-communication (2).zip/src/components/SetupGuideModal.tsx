import React, { useState, useEffect } from 'react';
import {
  X,
  Copy,
  Check,
  Database,
  ShieldCheck,
  Camera,
  Server,
  Layers,
  HelpCircle,
  ExternalLink,
} from 'lucide-react';

interface SetupGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SetupGuideModal: React.FC<SetupGuideModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'sql' | 'storage' | 'roboflow' | 'sos'>('sql');
  const [backendStatus, setBackendStatus] = useState<{
    roboflowConfigured?: boolean;
    roboflowModel?: string;
    sosConfigured?: boolean;
  } | null>(null);

  useEffect(() => {
    if (isOpen) {
      fetch('/api/status')
        .then((res) => res.json())
        .then((data) => setBackendStatus(data))
        .catch(() => setBackendStatus(null));
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const sqlCode = `-- ==============================================================================
-- SAMVAAD — Indian Sign Language Two-Way Communication Database Schema
-- Run in: Supabase Dashboard -> SQL Editor -> New Query -> Run
-- ==============================================================================

CREATE TABLE IF NOT EXISTS public.isl_videos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    phrase VARCHAR(255) NOT NULL,
    keywords TEXT[] DEFAULT '{}',
    description TEXT,
    video_url TEXT NOT NULL,
    category VARCHAR(100) DEFAULT 'general',
    is_verified BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE INDEX IF NOT EXISTS idx_isl_videos_phrase_lower 
ON public.isl_videos (LOWER(TRIM(phrase)));

CREATE INDEX IF NOT EXISTS idx_isl_videos_keywords 
ON public.isl_videos USING GIN (keywords);

CREATE INDEX IF NOT EXISTS idx_isl_videos_verified 
ON public.isl_videos (is_verified) 
WHERE is_verified = true;

ALTER TABLE public.isl_videos ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow unauthenticated read of verified sign videos" ON public.isl_videos;
CREATE POLICY "Allow unauthenticated read of verified sign videos"
ON public.isl_videos
FOR SELECT
TO anon, authenticated
USING (is_verified = true);

CREATE POLICY "Prevent public insert of sign videos"
ON public.isl_videos FOR INSERT TO authenticated WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Prevent public update of sign videos"
ON public.isl_videos FOR UPDATE TO authenticated USING (auth.role() = 'authenticated');

CREATE POLICY "Prevent public delete of sign videos"
ON public.isl_videos FOR DELETE TO authenticated USING (auth.role() = 'authenticated');

-- Sample unverified seeds (replace video_url with verified signs from your storage bucket)
INSERT INTO public.isl_videos (phrase, keywords, description, video_url, category, is_verified)
VALUES
    ('Hello', ARRAY['hello', 'hi', 'namaste'], 'Open hand moves outwards from forehead.', 'https://cdnnjivtfzzfihgzlzys.supabase.co/storage/v1/object/public/isl-videos/sample_hello.mp4', 'greetings', false),
    ('Thank you', ARRAY['thank', 'thanks', 'dhanyawad'], 'Fingertips touch chin and extend outward.', 'https://cdnnjivtfzzfihgzlzys.supabase.co/storage/v1/object/public/isl-videos/sample_thank_you.mp4', 'courtesy', false),
    ('Yes', ARRAY['yes', 'haan', 'correct'], 'Fist gently nods up and down.', 'https://cdnnjivtfzzfihgzlzys.supabase.co/storage/v1/object/public/isl-videos/sample_yes.mp4', 'affirmation', false),
    ('No', ARRAY['no', 'nahin', 'false'], 'Index finger wags or snaps with thumb.', 'https://cdnnjivtfzzfihgzlzys.supabase.co/storage/v1/object/public/isl-videos/sample_no.mp4', 'negation', false),
    ('Please', ARRAY['please', 'kripya'], 'Flat palm rubs in gentle circular motion over chest.', 'https://cdnnjivtfzzfihgzlzys.supabase.co/storage/v1/object/public/isl-videos/sample_please.mp4', 'courtesy', false)
ON CONFLICT DO NOTHING;`;

  const handleCopySql = () => {
    navigator.clipboard.writeText(sqlCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden">
        {/* Modal Top Bar */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <Database className="w-5 h-5 text-indigo-600" />
            <h2 className="text-base font-bold text-slate-900">
              SAMVAAD — Setup & Deployment Architecture
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 px-6 gap-2 bg-white text-xs font-medium">
          <button
            onClick={() => setActiveTab('sql')}
            className={`py-3 px-3 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'sql'
                ? 'border-indigo-600 text-indigo-600 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            <span>1. Supabase SQL Schema</span>
          </button>
          <button
            onClick={() => setActiveTab('storage')}
            className={`py-3 px-3 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'storage'
                ? 'border-indigo-600 text-indigo-600 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>2. Storage Bucket</span>
          </button>
          <button
            onClick={() => setActiveTab('roboflow')}
            className={`py-3 px-3 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'roboflow'
                ? 'border-indigo-600 text-indigo-600 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Camera className="w-3.5 h-3.5" />
            <span>3. Roboflow Backend</span>
          </button>
          <button
            onClick={() => setActiveTab('sos')}
            className={`py-3 px-3 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'sos'
                ? 'border-indigo-600 text-indigo-600 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>4. SOS Providers</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-6 overflow-y-auto space-y-4 text-xs text-slate-700">
          {activeTab === 'sql' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-sm text-slate-900">
                    Supabase SQL Editor Query (schema.sql)
                  </h3>
                  <p className="text-slate-500">
                    Creates <code className="font-mono text-slate-800">public.isl_videos</code>, RLS policies, keyword indices, and unverified placeholders.
                  </p>
                </div>
                <button
                  onClick={handleCopySql}
                  className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-md font-semibold text-xs flex items-center gap-1.5 transition-colors"
                >
                  {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied SQL' : 'Copy Full SQL'}</span>
                </button>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
                <ol className="list-decimal list-inside space-y-1 text-slate-600">
                  <li>Open your Supabase Project: <a href="https://supabase.com/dashboard/project/cdnnjivtfzzfihgzlzys" target="_blank" rel="noreferrer" className="text-indigo-600 underline">cdnnjivtfzzfihgzlzys</a></li>
                  <li>Click <strong>SQL Editor</strong> on the left sidebar.</li>
                  <li>Click <strong>+ New Query</strong>.</li>
                  <li>Paste the script below and click <strong>Run</strong> (or press Cmd+Enter).</li>
                </ol>
              </div>

              <pre className="p-4 bg-slate-900 text-slate-100 rounded-xl font-mono text-[11px] leading-relaxed overflow-x-auto max-h-72 border border-slate-800 select-all">
                {sqlCode}
              </pre>
            </div>
          )}

          {activeTab === 'storage' && (
            <div className="space-y-4">
              <h3 className="font-bold text-sm text-slate-900">
                Supabase Storage Bucket Setup: <code className="font-mono text-indigo-600">isl-videos</code>
              </h3>

              <div className="space-y-2 leading-relaxed">
                <p>
                  SAMVAAD streams ISL demonstration videos directly from Supabase Storage. Follow these steps to configure the storage bucket:
                </p>
                <ol className="list-decimal list-inside space-y-2 bg-slate-50 p-4 border border-slate-200 rounded-xl">
                  <li>
                    Go to <strong>Supabase Dashboard → Storage</strong>.
                  </li>
                  <li>
                    Click <strong>New Bucket</strong>.
                  </li>
                  <li>
                    Name the bucket exactly: <code className="font-mono bg-white px-1.5 py-0.5 rounded border border-slate-200 font-semibold text-slate-800">isl-videos</code>
                  </li>
                  <li>
                    Check <strong>Public Bucket</strong> (so approved ISL videos can be viewed in the video player by both hearing and ISL users).
                  </li>
                  <li>
                    Upload your recorded <code className="font-mono">.mp4</code> or <code className="font-mono">.webm</code> videos (e.g. <code className="font-mono">hello.mp4</code>, <code className="font-mono">thank_you.mp4</code>).
                  </li>
                  <li>
                    Copy the video URL and update the row in <code className="font-mono">public.isl_videos</code> with <code className="font-mono">is_verified = true</code>.
                  </li>
                </ol>
              </div>
            </div>
          )}

          {activeTab === 'roboflow' && (
            <div className="space-y-4">
              <h3 className="font-bold text-sm text-slate-900">
                Roboflow Computer Vision Server-Side Proxy
              </h3>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between">
                <div>
                  <span className="font-semibold block text-slate-800">Backend Server Status:</span>
                  <span className="text-[11px] text-slate-500">
                    Model: <code className="font-mono">{backendStatus?.roboflowModel || 'indian-sign-language-fkx1f-8kfux/1'}</code>
                  </span>
                </div>
                <span
                  className={`px-2.5 py-1 rounded text-xs font-semibold ${
                    backendStatus?.roboflowConfigured
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-rose-100 text-rose-800'
                  }`}
                >
                  {backendStatus?.roboflowConfigured ? 'Key Configured' : 'Key Missing'}
                </span>
              </div>

              <div className="space-y-2">
                <p>
                  For security, Roboflow API keys are stored exclusively on the server inside <code className="font-mono text-slate-900">.env</code> and proxied through <code className="font-mono text-slate-900">POST /api/infer-sign</code>.
                </p>
                <div className="p-3 bg-slate-900 text-slate-100 rounded-lg font-mono text-[11px]">
                  # In your server environment (.env):<br />
                  ROBOFLOW_API_KEY=your_rotated_roboflow_key_here<br />
                  ROBOFLOW_MODEL_ID=indian-sign-language-fkx1f-8kfux/1<br />
                  ROBOFLOW_CONFIDENCE_THRESHOLD=0.50
                </div>
              </div>
            </div>
          )}

          {activeTab === 'sos' && (
            <div className="space-y-4">
              <h3 className="font-bold text-sm text-slate-900">
                Emergency SOS Dispatch Integration
              </h3>

              <div className="space-y-2 leading-relaxed">
                <p>
                  SAMVAAD strictly adheres to transparent emergency handling: it will never pretend an alert was dispatched if no notification channel is configured.
                </p>

                <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                  <span className="font-semibold text-slate-800 block">
                    Supported Notification Channels:
                  </span>
                  <ul className="list-disc list-inside space-y-1 text-slate-600">
                    <li>
                      <strong>Webhook URL:</strong> Set <code className="font-mono">SOS_NOTIFICATION_WEBHOOK_URL</code> to post JSON emergency dispatch payloads.
                    </li>
                    <li>
                      <strong>Twilio SMS:</strong> Configure <code className="font-mono">TWILIO_ACCOUNT_SID</code>, <code className="font-mono">TWILIO_AUTH_TOKEN</code>, <code className="font-mono">TWILIO_FROM_PHONE</code>, and <code className="font-mono">SOS_RECIPIENT_PHONE</code>.
                    </li>
                    <li>
                      <strong>Direct Fallback:</strong> If unconfigured, the app provides instant click-to-call buttons for national Indian emergency numbers (<strong>112</strong>, <strong>100</strong>, <strong>108</strong>, <strong>1091</strong>).
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-medium text-xs rounded-lg transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
