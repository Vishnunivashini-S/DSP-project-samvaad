import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Video,
  VideoOff,
  Volume2,
  Scan,
  AlertTriangle,
  RotateCcw,
  Sliders,
  HelpCircle,
  Loader2,
  VolumeX,
  Upload,
  ExternalLink,
  Sparkles,
  CheckCircle2,
} from 'lucide-react';
import type { PredictionResult, InferenceResponse } from '../types';

const MODEL_CLASSES = [
  { name: 'Bad', category: 'General', symbol: '👎' },
  { name: 'Brother', category: 'Family', symbol: '👦' },
  { name: 'Father', category: 'Family', symbol: '👨' },
  { name: 'Food', category: 'Needs', symbol: '🍲' },
  { name: 'Friend', category: 'People', symbol: '🤝' },
  { name: 'Good', category: 'General', symbol: '👍' },
  { name: 'Hello', category: 'Greetings', symbol: '👋' },
  { name: 'Help', category: 'Urgent', symbol: '🆘' },
  { name: 'House', category: 'Places', symbol: '🏠' },
  { name: 'I', category: 'Pronoun', symbol: '🙋' },
  { name: 'Indian', category: 'Identity', symbol: '🇮🇳' },
  { name: 'Loud', category: 'Sound', symbol: '📢' },
  { name: 'Mummy', category: 'Family', symbol: '👩' },
  { name: 'Namaste', category: 'Greetings', symbol: '🙏' },
  { name: 'Name', category: 'Identity', symbol: '📛' },
  { name: 'No', category: 'Basics', symbol: '☝️' },
  { name: 'Place', category: 'Places', symbol: '📍' },
  { name: 'Please', category: 'Courtesy', symbol: '🤲' },
  { name: 'Quiet', category: 'Sound', symbol: '🤫' },
  { name: 'Sleeping', category: 'Needs', symbol: '😴' },
  { name: 'Sorry', category: 'Courtesy', symbol: '🙇' },
  { name: 'Strong', category: 'General', symbol: '💪' },
  { name: 'Thank-you', category: 'Courtesy', symbol: '🙌' },
  { name: 'Time', category: 'Common', symbol: '⏰' },
  { name: 'Today', category: 'Common', symbol: '📅' },
  { name: 'Water', category: 'Needs', symbol: '💧' },
  { name: 'What', category: 'Question', symbol: '❓' },
  { name: 'Yes', category: 'Basics', symbol: '✊' },
  { name: 'Your', category: 'Pronoun', symbol: '👉' },
  { name: 'language', category: 'ISL', symbol: '🗣️' },
  { name: 'sign', category: 'ISL', symbol: '👐' },
  { name: 'you', category: 'Pronoun', symbol: '👤' },
];

export const SignToSpeech: React.FC = () => {
  // Camera & Recognition States
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isRecognizing, setIsRecognizing] = useState(false);
  const [isInferring, setIsInferring] = useState(false);

  // Recognition Results
  const [currentPrediction, setCurrentPrediction] = useState<PredictionResult | null>(null);
  const [bestCandidate, setBestCandidate] = useState<PredictionResult | null>(null);
  const [lastRecognizedText, setLastRecognizedText] = useState<string>('');
  const [noMatchMessage, setNoMatchMessage] = useState<string | null>(null);
  const [confidenceThreshold, setConfidenceThreshold] = useState<number>(0.50);
  const [autoSpeak, setAutoSpeak] = useState(true);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [ttsSupported, setTtsSupported] = useState(true);

  // Uploaded Image Fallback
  const [uploadedImagePreview, setUploadedImagePreview] = useState<string | null>(null);

  // Backend status
  const [backendError, setBackendError] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const overlayCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const recognitionIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const lastSpokenClassRef = useRef<string>('');

  // Check SpeechSynthesis support
  useEffect(() => {
    if (!('speechSynthesis' in window) || !('SpeechSynthesisUtterance' in window)) {
      setTtsSupported(false);
    }
  }, []);

  // Ensure video element plays the stream whenever camera becomes active
  useEffect(() => {
    if (isCameraActive && mediaStreamRef.current && videoRef.current) {
      if (videoRef.current.srcObject !== mediaStreamRef.current) {
        videoRef.current.srcObject = mediaStreamRef.current;
      }
      videoRef.current.play().catch((err) => {
        console.warn('Video playback warning:', err);
      });
    }
  }, [isCameraActive]);

  // Speak text aloud using browser SpeechSynthesis API
  const speakText = useCallback(
    (textToSpeak: string) => {
      if (!ttsSupported || !textToSpeak.trim()) return;

      try {
        window.speechSynthesis.cancel(); // Cancel previous utterance

        const utterance = new SpeechSynthesisUtterance(textToSpeak);
        utterance.rate = 0.95;
        utterance.pitch = 1.0;
        utterance.lang = 'en-IN';

        const voices = window.speechSynthesis.getVoices();
        const preferredVoice = voices.find(
          (v) => v.lang === 'en-IN' || v.name.includes('India') || v.lang.startsWith('en')
        );
        if (preferredVoice) {
          utterance.voice = preferredVoice;
        }

        utterance.onstart = () => setIsSpeaking(true);
        utterance.onend = () => setIsSpeaking(false);
        utterance.onerror = () => setIsSpeaking(false);

        window.speechSynthesis.speak(utterance);
      } catch (err) {
        console.warn('TTS error:', err);
        setIsSpeaking(false);
      }
    },
    [ttsSupported]
  );

  // Start Camera
  const startCamera = async (): Promise<boolean> => {
    setCameraError(null);
    setUploadedImagePreview(null);
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error(
          'Camera API is not accessible in this context. If you are inside an embedded iframe, please click "Open in Full Tab" above.'
        );
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: 'user',
        },
        audio: false,
      });

      mediaStreamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }

      setIsCameraActive(true);
      return true;
    } catch (err: unknown) {
      const errorMsg = err instanceof Error ? err.message : 'Failed to access camera.';
      console.error('Camera access error:', err);

      if (
        errorMsg.includes('Permission denied') ||
        errorMsg.includes('NotAllowedError') ||
        errorMsg.includes('PermissionDismissedError')
      ) {
        setCameraError(
          'Camera access was blocked or dismissed. Please allow camera permissions in your browser URL bar (lock/camera icon) or open the app in a dedicated tab.'
        );
      } else if (errorMsg.includes('NotFoundError') || errorMsg.includes('DevicesNotFoundError')) {
        setCameraError('No webcam device was found on this system. You can use the "Upload Test Image" button to test sign recognition.');
      } else {
        setCameraError(errorMsg);
      }
      setIsCameraActive(false);
      return false;
    }
  };

  // Stop Camera
  const stopCamera = () => {
    stopRecognition();
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);

    if (overlayCanvasRef.current) {
      const ctx = overlayCanvasRef.current.getContext('2d');
      ctx?.clearRect(0, 0, overlayCanvasRef.current.width, overlayCanvasRef.current.height);
    }
  };

  // Draw bounding box on overlay canvas
  const drawOverlayBBox = (
    prediction: PredictionResult | null,
    imgWidth: number,
    imgHeight: number,
    isCandidate = false
  ) => {
    const canvas = overlayCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    if (!prediction || !prediction.bbox) return;

    const { x, y, width, height } = prediction.bbox;

    const scaleX = canvas.width / imgWidth;
    const scaleY = canvas.height / imgHeight;

    const boxX = (x - width / 2) * scaleX;
    const boxY = (y - height / 2) * scaleY;
    const boxW = width * scaleX;
    const boxH = height * scaleY;

    if (isCandidate) {
      // Amber dashed border for candidate below threshold
      ctx.strokeStyle = '#F59E0B';
      ctx.lineWidth = 2.5;
      ctx.setLineDash([6, 4]);
      ctx.strokeRect(boxX, boxY, boxW, boxH);
      ctx.setLineDash([]);

      ctx.fillStyle = '#F59E0B';
      const label = `Candidate: ${prediction.class} (${(prediction.confidence * 100).toFixed(0)}%)`;
      ctx.font = 'bold 12px Plus Jakarta Sans, sans-serif';
      const textWidth = ctx.measureText(label).width;
      ctx.fillRect(boxX, Math.max(0, boxY - 22), textWidth + 10, 22);

      ctx.fillStyle = '#FFFFFF';
      ctx.fillText(label, boxX + 5, Math.max(15, boxY - 6));
    } else {
      // Solid emerald border for confirmed prediction
      ctx.strokeStyle = '#10B981';
      ctx.lineWidth = 3;
      ctx.setLineDash([]);
      ctx.strokeRect(boxX, boxY, boxW, boxH);

      ctx.fillStyle = '#10B981';
      const label = `${prediction.class} (${(prediction.confidence * 100).toFixed(1)}%)`;
      ctx.font = 'bold 13px Plus Jakarta Sans, sans-serif';
      const textWidth = ctx.measureText(label).width;
      ctx.fillRect(boxX, Math.max(0, boxY - 24), textWidth + 12, 24);

      ctx.fillStyle = '#FFFFFF';
      ctx.fillText(label, boxX + 6, Math.max(16, boxY - 7));
    }
  };

  // Execute inference on an image payload
  const runInferenceOnPayload = async (dataUrl: string, imgW: number, imgH: number) => {
    setIsInferring(true);
    setBackendError(null);

    try {
      const response = await fetch('/api/infer-sign', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          image: dataUrl,
          threshold: confidenceThreshold,
        }),
      });

      if (!response.ok) {
        const errorJson = await response.json().catch(() => ({}));
        if (response.status === 503 && errorJson.unconfigured) {
          setBackendError(
            'Roboflow API key is not configured on the backend. Please add ROBOFLOW_API_KEY to your backend environment (.env).'
          );
        } else {
          setBackendError(errorJson.details || errorJson.error || 'Server inference failed.');
        }
        setIsInferring(false);
        return;
      }

      const resData: InferenceResponse = await response.json();

      if (resData.topPrediction) {
        // High confidence match
        const pred = resData.topPrediction;
        setCurrentPrediction(pred);
        setBestCandidate(null);
        setLastRecognizedText(pred.class);
        setNoMatchMessage(null);

        drawOverlayBBox(pred, imgW, imgH, false);

        if (autoSpeak && lastSpokenClassRef.current !== pred.class) {
          lastSpokenClassRef.current = pred.class;
          speakText(pred.class);
        }
      } else if (resData.bestCandidate) {
        // Detected sign, but confidence was slightly below threshold
        const candidate = resData.bestCandidate;
        setCurrentPrediction(null);
        setBestCandidate(candidate);
        setNoMatchMessage(
          `Detected candidate gesture "${candidate.class}" with ${(candidate.confidence * 100).toFixed(0)}% confidence (below your ${(confidenceThreshold * 100).toFixed(0)}% threshold).`
        );
        drawOverlayBBox(candidate, imgW, imgH, true);
      } else {
        // No bounding box found
        setCurrentPrediction(null);
        setBestCandidate(null);
        setNoMatchMessage('Sign not recognized clearly. Please try again.');
        if (overlayCanvasRef.current) {
          const oCtx = overlayCanvasRef.current.getContext('2d');
          oCtx?.clearRect(0, 0, overlayCanvasRef.current.width, overlayCanvasRef.current.height);
        }
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Inference request failed';
      console.warn('Sign inference error:', msg);
      setBackendError(msg);
    } finally {
      setIsInferring(false);
    }
  };

  // Capture current video frame and infer through server proxy
  const captureAndInfer = useCallback(async () => {
    if (!videoRef.current || !isCameraActive || isInferring) return;

    const video = videoRef.current;
    if (video.videoWidth === 0 || video.videoHeight === 0) return;

    let captureCanvas = canvasRef.current;
    if (!captureCanvas) {
      captureCanvas = document.createElement('canvas');
      canvasRef.current = captureCanvas;
    }

    captureCanvas.width = video.videoWidth;
    captureCanvas.height = video.videoHeight;
    const ctx = captureCanvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);
    const dataUrl = captureCanvas.toDataURL('image/jpeg', 0.85);

    await runInferenceOnPayload(dataUrl, video.videoWidth, video.videoHeight);
  }, [isCameraActive, isInferring, confidenceThreshold, autoSpeak, speakText]);

  // Handle uploaded static image file
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    stopCamera();

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      setUploadedImagePreview(result);

      const img = new Image();
      img.onload = () => {
        runInferenceOnPayload(result, img.width, img.height);
      };
      img.src = result;
    };
    reader.readAsDataURL(file);
  };

  // Start continuous recognition loop
  const startRecognition = async () => {
    if (!isCameraActive || !mediaStreamRef.current) {
      const started = await startCamera();
      if (!started) return;
    }

    setIsRecognizing(true);
    setNoMatchMessage(null);
    lastSpokenClassRef.current = '';
  };

  const stopRecognition = () => {
    setIsRecognizing(false);
    if (recognitionIntervalRef.current) {
      clearInterval(recognitionIntervalRef.current);
      recognitionIntervalRef.current = null;
    }
  };

  // Continuous inference loop
  useEffect(() => {
    if (isRecognizing && isCameraActive) {
      captureAndInfer();
      recognitionIntervalRef.current = setInterval(() => {
        captureAndInfer();
      }, 1000);
    } else {
      if (recognitionIntervalRef.current) {
        clearInterval(recognitionIntervalRef.current);
        recognitionIntervalRef.current = null;
      }
    }

    return () => {
      if (recognitionIntervalRef.current) {
        clearInterval(recognitionIntervalRef.current);
        recognitionIntervalRef.current = null;
      }
    };
  }, [isRecognizing, isCameraActive, captureAndInfer]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      }
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
      {/* Panel Header */}
      <div className="px-6 py-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-emerald-600 block mb-1">
            Direction 02
          </span>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
            Sign Language → Text → Speech
          </h2>
          <p className="text-sm text-slate-500 mt-0.5">
            Roboflow vision gesture recognition for ISL communicators with automated speech synthesis.
          </p>
        </div>

        {/* Model ID and threshold */}
        <div className="flex items-center gap-3 text-xs text-slate-500 font-medium">
          <span>Model: indian-sign-language-fkx1f-8kfux/1</span>
          <span aria-hidden="true">·</span>
          <span>32 Classes</span>
          <span aria-hidden="true">·</span>
          <span>Threshold: {(confidenceThreshold * 100).toFixed(0)}%</span>
        </div>
      </div>

      <div className="p-6 grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        {/* Left Column: Camera Viewport */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-semibold text-slate-700">Camera Feed</h3>
            <div className="flex items-center gap-3">
              <a
                href={window.location.href}
                target="_blank"
                rel="noreferrer"
                className="text-xs text-indigo-600 hover:text-indigo-800 flex items-center gap-1 font-medium"
                title="If camera permissions are blocked by the preview frame, open in full tab"
              >
                <span>Open Full Tab</span>
                <ExternalLink className="w-3 h-3" />
              </a>

              {isInferring && (
                <span className="text-xs text-indigo-600 font-medium flex items-center gap-1.5">
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  Analyzing...
                </span>
              )}
            </div>
          </div>

          {/* Camera Viewport Container: Video is always mounted to prevent null ref */}
          <div className="relative aspect-video w-full bg-slate-950 rounded-xl overflow-hidden border border-slate-800 flex items-center justify-center">
            {/* Live Video Element */}
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className={`w-full h-full object-cover transform scale-x-[-1] transition-opacity duration-200 ${
                isCameraActive && !uploadedImagePreview ? 'opacity-100' : 'opacity-0 absolute'
              }`}
            />

            {/* Uploaded Image Preview (if user uploaded a test image) */}
            {uploadedImagePreview && (
              <img
                src={uploadedImagePreview}
                alt="Uploaded ISL frame"
                className="w-full h-full object-contain"
              />
            )}

            {/* Bounding Box Overlay Canvas */}
            <canvas
              ref={overlayCanvasRef}
              width={640}
              height={480}
              className={`absolute inset-0 w-full h-full pointer-events-none ${
                uploadedImagePreview ? '' : 'transform scale-x-[-1]'
              }`}
            />

            {/* Standby / Offline State Overlay */}
            {!isCameraActive && !uploadedImagePreview && (
              <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center space-y-3 bg-slate-950">
                <div className="w-12 h-12 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center">
                  <VideoOff className="w-6 h-6 text-slate-500" />
                </div>
                <div className="space-y-1 max-w-xs">
                  <p className="text-xs font-semibold text-slate-200">Camera is Offline</p>
                  <p className="text-[11px] text-slate-400">
                    Click &ldquo;Start Camera&rdquo; below or upload a sign gesture image to begin ISL recognition.
                  </p>
                </div>
              </div>
            )}

            {/* Active Recognition Badge */}
            {isCameraActive && (
              <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-xs px-2.5 py-1 rounded-md text-[11px] font-medium text-white flex items-center gap-2">
                <span
                  className={`w-2 h-2 rounded-full ${
                    isRecognizing ? 'bg-emerald-400 animate-pulse' : 'bg-slate-400'
                  }`}
                />
                <span>{isRecognizing ? 'Continuous ISL Recognition' : 'Camera Standby'}</span>
              </div>
            )}
          </div>

          {/* Camera Error Message */}
          {cameraError && (
            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-lg flex items-start gap-2.5 text-xs text-rose-900">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div className="space-y-1.5 flex-1">
                <p className="font-semibold">Camera Access Notice</p>
                <p className="text-rose-800 leading-relaxed">{cameraError}</p>
                <div className="pt-1 flex items-center gap-3">
                  <a
                    href={window.location.href}
                    target="_blank"
                    rel="noreferrer"
                    className="font-bold underline text-rose-950 hover:text-black flex items-center gap-1"
                  >
                    Open app directly in new browser tab
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            </div>
          )}

          {/* Backend Error Message */}
          {backendError && (
            <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-lg flex items-start gap-2.5 text-xs text-amber-900">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="font-semibold">Inference Model Warning</p>
                <p className="text-amber-800">{backendError}</p>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-3 pt-1">
            {!isCameraActive ? (
              <button
                onClick={startCamera}
                className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-semibold text-sm rounded-lg shadow-xs transition-colors flex items-center gap-2"
              >
                <Video className="w-4 h-4" />
                <span>Start Camera</span>
              </button>
            ) : (
              <button
                onClick={stopCamera}
                className="px-4 py-2.5 bg-slate-800 hover:bg-slate-900 active:bg-black text-white font-medium text-sm rounded-lg transition-colors flex items-center gap-2"
              >
                <VideoOff className="w-4 h-4" />
                <span>Stop Camera</span>
              </button>
            )}

            {!isRecognizing ? (
              <button
                onClick={startRecognition}
                className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white font-semibold text-sm rounded-lg shadow-xs transition-colors flex items-center gap-2"
              >
                <Scan className="w-4 h-4" />
                <span>Start Recognition</span>
              </button>
            ) : (
              <button
                onClick={stopRecognition}
                className="px-4 py-2.5 bg-amber-600 hover:bg-amber-700 active:bg-amber-800 text-white font-semibold text-sm rounded-lg shadow-xs transition-colors flex items-center gap-2"
              >
                <Scan className="w-4 h-4" />
                <span>Stop Recognition</span>
              </button>
            )}

            {isCameraActive && (
              <button
                onClick={() => captureAndInfer()}
                disabled={isInferring}
                className="px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-medium text-xs rounded-lg transition-colors flex items-center gap-1.5"
                title="Capture and recognize single frame"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Capture Frame</span>
              </button>
            )}

            {/* Upload Test Image Fallback */}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileUpload}
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="px-3 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium text-xs rounded-lg transition-colors flex items-center gap-1.5"
              title="Upload an ISL gesture image directly"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Upload Test Image</span>
            </button>
          </div>

          {/* Supported Gestures of this Roboflow Model */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                <span>Model Vocabulary (32 Indian Sign Language Words):</span>
              </span>
              <span className="text-[11px] text-slate-500 font-mono">32 classes</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 max-h-60 overflow-y-auto pr-1">
              {MODEL_CLASSES.map((cls) => (
                <div
                  key={cls.name}
                  className="p-2 bg-white border border-slate-200 rounded-lg flex items-center justify-between hover:border-indigo-300 transition-colors group"
                >
                  <span className="text-xs font-bold text-slate-800 flex items-center gap-1 truncate">
                    <span>{cls.symbol}</span>
                    <span className="truncate">{cls.name}</span>
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      const simulated: PredictionResult = {
                        class: cls.name,
                        confidence: 0.91,
                      };
                      setCurrentPrediction(simulated);
                      setLastRecognizedText(cls.name);
                      setBestCandidate(null);
                      setNoMatchMessage(null);
                      speakText(cls.name);
                    }}
                    className="text-[10px] text-indigo-600 group-hover:underline font-semibold shrink-0 ml-1"
                    title={`Simulate TTS for ${cls.name}`}
                  >
                    Test
                  </button>
                </div>
              ))}
            </div>
            <p className="text-[11px] text-slate-400">
              Click &ldquo;Test&rdquo; on any word above to preview its pronunciation.
            </p>
          </div>
        </div>

        {/* Right Column: Output & TTS Controls */}
        <div className="space-y-5">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-semibold text-slate-700">Recognition Output</h3>
            <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-600">
              <input
                type="checkbox"
                checked={autoSpeak}
                onChange={(e) => setAutoSpeak(e.target.checked)}
                className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300"
              />
              <span>Auto-speak new signs</span>
            </label>
          </div>

          {/* Recognized Text Display Box */}
          <div className="p-6 bg-slate-50 border border-slate-200 rounded-xl space-y-4">
            <div className="space-y-1">
              <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">
                Recognized Sign Text
              </span>
              <div className="min-h-[64px] flex items-center">
                {currentPrediction ? (
                  <div className="flex items-baseline gap-3">
                    <span className="text-3xl font-extrabold text-slate-900 tracking-tight">
                      {currentPrediction.class}
                    </span>
                    <span className="text-sm font-semibold text-emerald-600 font-mono tabular-nums">
                      {(currentPrediction.confidence * 100).toFixed(1)}% Confidence
                    </span>
                  </div>
                ) : bestCandidate ? (
                  <div className="space-y-2 w-full">
                    <div className="flex items-baseline justify-between">
                      <span className="text-2xl font-bold text-amber-900">
                        {bestCandidate.class}
                      </span>
                      <span className="text-xs font-mono font-semibold text-amber-700">
                        {(bestCandidate.confidence * 100).toFixed(1)}% (Candidate)
                      </span>
                    </div>
                    <p className="text-xs text-amber-800">
                      Detected below your current {(confidenceThreshold * 100).toFixed(0)}% threshold.
                    </p>
                    <div className="flex flex-wrap gap-2 pt-1">
                      <button
                        onClick={() => {
                          setCurrentPrediction(bestCandidate);
                          setLastRecognizedText(bestCandidate.class);
                          speakText(bestCandidate.class);
                        }}
                        className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded text-xs font-semibold shadow-xs transition-colors"
                      >
                        Accept & Speak &ldquo;{bestCandidate.class}&rdquo;
                      </button>
                      <button
                        onClick={() => {
                          setConfidenceThreshold(
                            Math.max(0.20, Math.floor(bestCandidate.confidence * 100) / 100)
                          );
                        }}
                        className="px-3 py-1.5 bg-white border border-amber-300 text-amber-900 hover:bg-amber-50 rounded text-xs font-medium transition-colors"
                      >
                        Lower Threshold to {(bestCandidate.confidence * 100).toFixed(0)}%
                      </button>
                    </div>
                  </div>
                ) : noMatchMessage ? (
                  <div className="space-y-1">
                    <p className="text-sm font-medium text-amber-800 leading-snug">
                      {noMatchMessage}
                    </p>
                    <p className="text-[11px] text-slate-500">
                      Try lowering the Confidence Threshold slider below (e.g. to 25%-35%) or adjust hand lighting.
                    </p>
                  </div>
                ) : (
                  <p className="text-sm text-slate-400 italic">
                    Start recognition or upload an image to display recognized speech text.
                  </p>
                )}
              </div>
            </div>

            {/* Speak Result Button */}
            <div className="pt-2 flex flex-wrap items-center gap-3">
              <button
                onClick={() => speakText(lastRecognizedText || currentPrediction?.class || '')}
                disabled={!lastRecognizedText && !currentPrediction}
                className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 disabled:bg-slate-200 disabled:text-slate-400 text-white font-semibold text-xs sm:text-sm rounded-lg transition-colors flex items-center gap-2"
              >
                <Volume2 className={`w-4 h-4 ${isSpeaking ? 'animate-bounce' : ''}`} />
                <span>Speak Result</span>
              </button>

              {isSpeaking && (
                <span className="text-xs font-medium text-indigo-600 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-indigo-600 animate-ping" />
                  Speaking aloud...
                </span>
              )}
            </div>

            {!ttsSupported && (
              <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-md text-[11px] text-amber-800 flex items-center gap-1.5">
                <VolumeX className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                <span>Text-to-Speech (TTS) is not supported in this browser environment.</span>
              </div>
            )}
          </div>

          {/* Configurable Threshold Slider */}
          <div className="p-4 bg-white border border-slate-200 rounded-lg space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-700 flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-slate-400" />
                Confidence Threshold
              </span>
              <span className="font-mono font-bold text-slate-900 tabular-nums">
                {(confidenceThreshold * 100).toFixed(0)}%
              </span>
            </div>
            <input
              type="range"
              min="0.20"
              max="0.85"
              step="0.05"
              value={confidenceThreshold}
              onChange={(e) => setConfidenceThreshold(parseFloat(e.target.value))}
              className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
            />
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span>More sensitive (20%)</span>
              <span>Default (50%)</span>
              <span>Strict (85%)</span>
            </div>
            <p className="text-[11px] text-slate-500 pt-0.5">
              Tip: If &ldquo;Sign not recognized&rdquo; appears, drag the slider left to 25%–35% for higher gesture sensitivity.
            </p>
          </div>

          {/* Technical Protocol Info */}
          <div className="text-[11px] text-slate-400 space-y-1">
            <p>
              · Roboflow model <code className="font-mono text-slate-600">indian-sign-language-fkx1f-8kfux/1</code> trained on 32 Indian Sign Language gestures.
            </p>
            <p>
              · API key is secured on the backend and never exposed to the client.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
