import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Mic,
  MicOff,
  Search,
  RotateCcw,
  Play,
  Pause,
  AlertCircle,
  CheckCircle2,
  Globe,
  Loader2,
  VideoOff,
  Sparkles,
  Info,
} from 'lucide-react';
import { findVerifiedSignVideo, SearchMatchResult } from '../lib/supabase';
import type { IslVideo } from '../types';

// SpeechRecognition type declarations for Web Speech API
interface SpeechRecognitionEventLike {
  results: {
    [index: number]: {
      [index: number]: {
        transcript: string;
      };
      isFinal?: boolean;
    };
    length: number;
  };
}

interface SpeechRecognitionErrorEventLike {
  error: string;
  message?: string;
}

interface SpeechRecognitionInstance {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onstart: (() => void) | null;
  onresult: ((event: SpeechRecognitionEventLike) => void) | null;
  onerror: ((event: SpeechRecognitionErrorEventLike) => void) | null;
  onend: (() => void) | null;
}

declare global {
  interface Window {
    SpeechRecognition?: new () => SpeechRecognitionInstance;
    webkitSpeechRecognition?: new () => SpeechRecognitionInstance;
  }
}

const SUPPORTED_LANGUAGES = [
  { code: 'en-IN', label: 'English (India)' },
  { code: 'hi-IN', label: 'Hindi (भारत)' },
  { code: 'ta-IN', label: 'Tamil (தமிழ்)' },
  { code: 'te-IN', label: 'Telugu (తెలుగు)' },
  { code: 'mr-IN', label: 'Marathi (मराठी)' },
  { code: 'bn-IN', label: 'Bengali (বাংলা)' },
  { code: 'kn-IN', label: 'Kannada (ಕನ್ನಡ)' },
  { code: 'gu-IN', label: 'Gujarati (ગુજરાતી)' },
  { code: 'ml-IN', label: 'Malayalam (മലയാളം)' },
];

export const HearingToSign: React.FC = () => {
  const [isListening, setIsListening] = useState(false);
  const [selectedLang, setSelectedLang] = useState('en-IN');
  const [transcript, setTranscript] = useState('');
  const [interimTranscript, setInterimTranscript] = useState('');
  const [speechApiSupported, setSpeechApiSupported] = useState(true);
  const [speechError, setSpeechError] = useState<string | null>(null);

  // Video and Search states
  const [isSearching, setIsSearching] = useState(false);
  const [matchedVideo, setMatchedVideo] = useState<IslVideo | null>(null);
  const [searchResultInfo, setSearchResultInfo] = useState<SearchMatchResult | null>(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [videoError, setVideoError] = useState<string | null>(null);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1.0);
  const [isPlaying, setIsPlaying] = useState(false);

  const recognitionRef = useRef<SpeechRecognitionInstance | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Initialize Speech Recognition on mount
  useEffect(() => {
    const SpeechRecognitionClass =
      window.SpeechRecognition || window.webkitSpeechRecognition;

    if (!SpeechRecognitionClass) {
      setSpeechApiSupported(false);
      setSpeechError(
        'Speech Recognition API is not supported in this browser. Please use Chrome, Edge, or enter text manually below.'
      );
      return;
    }

    try {
      const recognition = new SpeechRecognitionClass();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = selectedLang;

      recognition.onstart = () => {
        setIsListening(true);
        setSpeechError(null);
      };

      recognition.onresult = (event: SpeechRecognitionEventLike) => {
        let finalTx = '';
        let interimTx = '';

        for (let i = 0; i < event.results.length; ++i) {
          const item = event.results[i];
          if (item.isFinal) {
            finalTx += item[0].transcript;
          } else {
            interimTx += item[0].transcript;
          }
        }

        if (finalTx) {
          setTranscript((prev) => {
            const updated = prev ? `${prev} ${finalTx}`.trim() : finalTx.trim();
            return updated;
          });
        }
        setInterimTranscript(interimTx);
      };

      recognition.onerror = (event: SpeechRecognitionErrorEventLike) => {
        console.warn('Speech recognition error:', event.error);
        if (event.error === 'not-allowed') {
          setSpeechError(
            'Microphone access was denied. Please allow microphone permissions in your browser address bar.'
          );
        } else if (event.error === 'no-speech') {
          // ignore silent timeouts
        } else {
          setSpeechError(`Speech recognition issue: ${event.error}`);
        }
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
        setInterimTranscript('');
      };

      recognitionRef.current = recognition;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to initialize speech';
      setSpeechApiSupported(false);
      setSpeechError(msg);
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }
    };
  }, [selectedLang]);

  // Execute database search for verified ISL videos
  const handleSearchVideo = useCallback(
    async (textToSearch?: string) => {
      const query = (textToSearch !== undefined ? textToSearch : transcript).trim();
      if (!query) return;

      setIsSearching(true);
      setVideoError(null);
      setHasSearched(true);

      const result = await findVerifiedSignVideo(query);
      setSearchResultInfo(result);
      setMatchedVideo(result.match);
      setIsSearching(false);

      if (result.match && videoRef.current) {
        videoRef.current.currentTime = 0;
        videoRef.current.play().catch(() => {
          // Autoplay policy may require user interaction
          setIsPlaying(false);
        });
      }
    },
    [transcript]
  );

  const startListening = () => {
    setSpeechError(null);
    if (!recognitionRef.current) return;
    try {
      recognitionRef.current.lang = selectedLang;
      recognitionRef.current.start();
    } catch (err: unknown) {
      console.warn('Error starting speech recognition:', err);
      // Restart if already running
      recognitionRef.current.abort();
      setTimeout(() => {
        recognitionRef.current?.start();
      }, 150);
    }
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      setIsListening(false);
      setInterimTranscript('');
      // Automatically search if transcript exists
      if (transcript.trim()) {
        handleSearchVideo();
      }
    }
  };

  const handleClear = () => {
    setTranscript('');
    setInterimTranscript('');
    setMatchedVideo(null);
    setSearchResultInfo(null);
    setHasSearched(false);
    setVideoError(null);
  };

  const handleReplay = () => {
    if (videoRef.current) {
      videoRef.current.currentTime = 0;
      videoRef.current.play();
      setIsPlaying(true);
    }
  };

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play();
      setIsPlaying(true);
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  };

  const handleSpeedChange = (speed: number) => {
    setPlaybackSpeed(speed);
    if (videoRef.current) {
      videoRef.current.playbackRate = speed;
    }
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
      {/* Panel Header */}
      <div className="px-6 py-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-indigo-600 block mb-1">
            Direction 01
          </span>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
            Speak → Text → Sign Language
          </h2>
          <p className="text-sm text-slate-500 mt-0.5">
            Voice capture for hearing participants with verified Indian Sign Language video lookup.
          </p>
        </div>

        {/* Language selector */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <Globe className="w-4 h-4 text-slate-400" />
          <select
            value={selectedLang}
            onChange={(e) => {
              setSelectedLang(e.target.value);
              if (isListening) {
                stopListening();
              }
            }}
            disabled={isListening}
            className="text-xs font-medium text-slate-700 bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            aria-label="Speech Recognition Language"
          >
            {SUPPORTED_LANGUAGES.map((lang) => (
              <option key={lang.code} value={lang.code}>
                {lang.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="p-6 grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        {/* Left Column: Voice Input & Transcription Area */}
        <div className="space-y-5">
          {/* Controls: Start/Stop Speech */}
          <div className="flex flex-wrap items-center gap-3">
            {!isListening ? (
              <button
                onClick={startListening}
                disabled={!speechApiSupported}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 disabled:bg-slate-300 text-white font-semibold text-sm rounded-lg shadow-xs transition-colors flex items-center gap-2"
              >
                <Mic className="w-4 h-4" />
                <span>Start Speaking</span>
              </button>
            ) : (
              <button
                onClick={stopListening}
                className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 active:bg-rose-800 text-white font-semibold text-sm rounded-lg shadow-xs transition-colors flex items-center gap-2"
              >
                <MicOff className="w-4 h-4" />
                <span>Stop Speaking</span>
              </button>
            )}

            <button
              onClick={() => handleSearchVideo()}
              disabled={isSearching || (!transcript.trim() && !interimTranscript.trim())}
              className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 active:bg-black disabled:bg-slate-200 disabled:text-slate-400 text-white font-medium text-sm rounded-lg transition-colors flex items-center gap-2"
            >
              {isSearching ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Searching...</span>
                </>
              ) : (
                <>
                  <Search className="w-4 h-4" />
                  <span>Find Sign Video</span>
                </>
              )}
            </button>

            {transcript && (
              <button
                onClick={handleClear}
                className="px-3 py-2 text-xs font-medium text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
              >
                Clear
              </button>
            )}
          </div>

          {/* Listening State Indicator */}
          {isListening && (
            <div className="p-3 bg-indigo-50/80 border border-indigo-200 rounded-lg flex items-center justify-between text-xs text-indigo-900">
              <div className="flex items-center gap-2.5">
                <span className="flex h-2.5 w-2.5 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-indigo-600"></span>
                </span>
                <span className="font-semibold">Listening to speech...</span>
                <span className="text-indigo-600">Speak clearly into microphone</span>
              </div>
              <span className="font-mono text-[11px] text-indigo-500">{selectedLang}</span>
            </div>
          )}

          {/* Speech Error Banner */}
          {speechError && (
            <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-lg flex items-start gap-2.5 text-xs text-amber-900">
              <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="font-semibold">Speech Input Notice</p>
                <p className="text-amber-800">{speechError}</p>
              </div>
            </div>
          )}

          {/* Transcript Display Box */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label htmlFor="transcript-input" className="text-xs font-semibold text-slate-700">
                Recognized Transcript
              </label>
              <span className="text-[11px] text-slate-400">
                You can also edit or type manually
              </span>
            </div>

            <div className="relative">
              <textarea
                id="transcript-input"
                rows={4}
                value={transcript}
                onChange={(e) => setTranscript(e.target.value)}
                placeholder="Spoken words will appear here in real-time. Or type a phrase like 'Hello', 'Thank you', 'Yes', 'No', 'Please'..."
                className="w-full p-3.5 text-sm font-medium text-slate-900 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white resize-none"
              />

              {interimTranscript && (
                <div className="absolute bottom-3 left-3 text-xs italic text-indigo-600 pointer-events-none truncate max-w-[90%]">
                  {interimTranscript}...
                </div>
              )}
            </div>
          </div>

          {/* Quick Verified Testing Chips (Direct query helpers) */}
          <div className="pt-2">
            <span className="text-xs font-medium text-slate-500 block mb-2">
              Common ISL Phrases (Database Seeds):
            </span>
            <div className="flex flex-wrap gap-1.5">
              {[
                'Hello',
                'Namaste',
                'Thank you',
                'Please',
                'Yes',
                'No',
                'Help',
                'Food',
                'Water',
                'Friend',
                'Father',
                'Mummy',
                'Good',
                'Sorry',
              ].map((sample) => (
                <button
                  key={sample}
                  type="button"
                  onClick={() => {
                    setTranscript(sample);
                    handleSearchVideo(sample);
                  }}
                  className="px-2.5 py-1 text-xs font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 hover:text-slate-900 rounded-md transition-colors"
                >
                  {sample}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: ISL Video Demonstration Player */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-semibold text-slate-700">
              Indian Sign Language Video
            </h3>
            {matchedVideo && (
              <span className="text-xs text-emerald-600 font-medium flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Verified ISL Record
              </span>
            )}
          </div>

          {/* Video Container */}
          <div className="relative aspect-video w-full bg-slate-900 rounded-xl overflow-hidden border border-slate-800 flex items-center justify-center">
            {isSearching ? (
              <div className="text-center p-6 space-y-2">
                <Loader2 className="w-8 h-8 text-indigo-400 animate-spin mx-auto" />
                <p className="text-xs text-slate-300">Searching verified ISL database...</p>
              </div>
            ) : matchedVideo && !videoError ? (
              <>
                <video
                  ref={videoRef}
                  src={matchedVideo.video_url}
                  className="w-full h-full object-contain"
                  playsInline
                  onPlay={() => setIsPlaying(true)}
                  onPause={() => setIsPlaying(false)}
                  onError={() => {
                    setVideoError(
                      `Video asset cannot be streamed from ${matchedVideo.video_url}. Ensure the video file exists in your Supabase 'isl-videos' storage bucket.`
                    );
                  }}
                />

                {/* Video Overlay Controls */}
                <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-3 flex items-center justify-between text-white text-xs">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={togglePlay}
                      className="p-1.5 hover:bg-white/20 rounded-md transition-colors"
                      title={isPlaying ? 'Pause' : 'Play'}
                    >
                      {isPlaying ? (
                        <Pause className="w-4 h-4" />
                      ) : (
                        <Play className="w-4 h-4 fill-white" />
                      )}
                    </button>
                    <button
                      onClick={handleReplay}
                      className="p-1.5 hover:bg-white/20 rounded-md transition-colors"
                      title="Replay Video"
                    >
                      <RotateCcw className="w-4 h-4" />
                    </button>
                    <span className="font-semibold text-xs ml-1">{matchedVideo.phrase}</span>
                  </div>

                  {/* Playback Speed Controls */}
                  <div className="flex items-center gap-1 bg-black/40 px-2 py-0.5 rounded-md">
                    <span className="text-[10px] text-slate-300 mr-1">Speed:</span>
                    {[0.5, 0.75, 1.0].map((rate) => (
                      <button
                        key={rate}
                        onClick={() => handleSpeedChange(rate)}
                        className={`px-1.5 py-0.5 rounded text-[11px] font-mono transition-colors ${
                          playbackSpeed === rate
                            ? 'bg-white/30 text-white font-bold'
                            : 'text-slate-300 hover:text-white'
                        }`}
                      >
                        {rate}x
                      </button>
                    ))}
                  </div>
                </div>
              </>
            ) : videoError ? (
              <div className="text-center p-6 space-y-2 max-w-sm">
                <VideoOff className="w-8 h-8 text-rose-400 mx-auto" />
                <p className="text-xs font-semibold text-white">Video Playback Error</p>
                <p className="text-[11px] text-slate-400">{videoError}</p>
              </div>
            ) : hasSearched && searchResultInfo?.error ? (
              <div className="text-center p-6 space-y-2 max-w-sm">
                <AlertCircle className="w-8 h-8 text-amber-400 mx-auto" />
                <p className="text-xs font-semibold text-white">Database Initialization Required</p>
                <p className="text-[11px] text-slate-300">
                  Supabase reported: {searchResultInfo.error}. Please run the database migration in <code className="font-mono text-indigo-300">supabase/schema.sql</code> in your Supabase SQL Editor.
                </p>
              </div>
            ) : hasSearched && !matchedVideo ? (
              <div className="text-center p-6 space-y-2 max-w-sm">
                <AlertCircle className="w-8 h-8 text-amber-400 mx-auto" />
                <p className="text-xs font-semibold text-white">No Verified ISL Match</p>
                <p className="text-[11px] text-slate-300">
                  No verified sign video found in database for &ldquo;{transcript}&rdquo;. SAMVAAD only plays genuine, verified signs to maintain communication accuracy.
                </p>
              </div>
            ) : (
              <div className="text-center p-6 space-y-2 max-w-xs">
                <Sparkles className="w-8 h-8 text-slate-500 mx-auto" />
                <p className="text-xs font-medium text-slate-300">
                  Ready for Voice or Text Input
                </p>
                <p className="text-[11px] text-slate-500">
                  Speak or search to view the verified Indian Sign Language demonstration video.
                </p>
              </div>
            )}
          </div>

          {/* Details / Verification Metadata */}
          {matchedVideo && (
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900 text-sm">
                  Sign: {matchedVideo.phrase}
                </span>
                <span className="text-slate-500">
                  Category: {matchedVideo.category || 'general'}
                </span>
              </div>

              {matchedVideo.description && (
                <p className="text-slate-600 leading-relaxed">
                  <strong className="text-slate-800">Gesture Description: </strong>
                  {matchedVideo.description}
                </p>
              )}

              {/* Partial Sentence Translation Warning */}
              {searchResultInfo?.isPartialSentence && (
                <div className="mt-2 p-2.5 bg-blue-50 border border-blue-200 rounded-md text-[11px] text-blue-900 flex items-start gap-2">
                  <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold">Grammar Notice</p>
                    <p className="text-blue-800">
                      Full sentence cannot be directly word-for-word translated to ISL. Displaying verified sign for keyword &ldquo;{searchResultInfo.matchedTerm}&rdquo;.
                      {searchResultInfo.untranslatedTerms && searchResultInfo.untranslatedTerms.length > 0 && (
                        <span> Untranslated words: {searchResultInfo.untranslatedTerms.join(', ')}.</span>
                      )}
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Informative Note */}
          <div className="text-[11px] text-slate-400 space-y-1">
            <p>
              · Table: <code className="font-mono text-slate-600">public.isl_videos</code> (Only records with <code className="font-mono text-slate-600">is_verified = true</code> are fetched).
            </p>
            <p>
              · To verify and add your own ISL videos, use the Supabase Dashboard SQL Editor & Storage bucket.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
