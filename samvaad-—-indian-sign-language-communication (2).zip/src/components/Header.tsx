import React from 'react';
import { ShieldAlert, HelpCircle } from 'lucide-react';

interface HeaderProps {
  activeTab: 'hearing-to-sign' | 'sign-to-hearing';
  onSelectTab: (tab: 'hearing-to-sign' | 'sign-to-hearing') => void;
  onOpenSos: () => void;
  onOpenSetup: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onSelectTab,
  onOpenSos,
  onOpenSetup,
}) => {
  return (
    <header className="border-b border-slate-200 bg-white sticky top-0 z-30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Brand Wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <span className="text-xl font-bold tracking-tight text-slate-900 whitespace-nowrap">
              SAMVAAD
            </span>
            <span className="hidden sm:inline-block text-xs font-medium text-slate-500 whitespace-nowrap">
              · Indian Sign Language Bridge
            </span>
          </div>

          {/* Zone 2: Navigation Links / Segmented Mode Control */}
          <nav className="flex items-center gap-1 sm:gap-2 bg-slate-100 p-1 rounded-lg">
            <button
              onClick={() => onSelectTab('hearing-to-sign')}
              className={`px-3 py-1.5 text-xs sm:text-sm font-medium rounded-md transition-colors whitespace-nowrap ${
                activeTab === 'hearing-to-sign'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Speak → Sign
            </button>
            <button
              onClick={() => onSelectTab('sign-to-hearing')}
              className={`px-3 py-1.5 text-xs sm:text-sm font-medium rounded-md transition-colors whitespace-nowrap ${
                activeTab === 'sign-to-hearing'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Sign → Speech
            </button>
          </nav>

          {/* Zone 3: Primary Action & Dedicated SOS Button */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            <button
              onClick={onOpenSetup}
              title="Database & Roboflow setup instructions"
              className="p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors text-xs font-medium flex items-center gap-1.5"
            >
              <HelpCircle className="w-4 h-4 text-slate-500" />
              <span className="hidden md:inline">Setup & SQL</span>
            </button>

            <button
              onClick={onOpenSos}
              className="px-3.5 py-1.5 sm:px-4 sm:py-2 text-xs sm:text-sm font-bold text-white bg-rose-600 hover:bg-rose-700 active:bg-rose-800 rounded-lg shadow-xs transition-colors flex items-center gap-1.5 tracking-wide whitespace-nowrap shrink-0"
              aria-label="Emergency SOS Alert"
            >
              <ShieldAlert className="w-4 h-4" />
              <span>SOS</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
