import React, { useState } from 'react';
import { Header } from './components/Header';
import { HearingToSign } from './components/HearingToSign';
import { SignToSpeech } from './components/SignToSpeech';
import { SosModal } from './components/SosModal';
import { SetupGuideModal } from './components/SetupGuideModal';
import { ArrowLeftRight, HelpCircle } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'hearing-to-sign' | 'sign-to-hearing'>('hearing-to-sign');
  const [isSosOpen, setIsSosOpen] = useState(false);
  const [isSetupOpen, setIsSetupOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans selection:bg-indigo-100 selection:text-indigo-900">
      {/* 1. Universal Top Bar Contract Header */}
      <Header
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onOpenSos={() => setIsSosOpen(true)}
        onOpenSetup={() => setIsSetupOpen(true)}
      />

      {/* 2. Main Workstation Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-6">
        {/* Direction Switcher Sub-Header Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200/80">
          <div className="space-y-1">
            <h1 className="text-lg sm:text-xl font-bold tracking-tight text-slate-900 flex items-center gap-2">
              <span>Two-Way Communication Console</span>
              <ArrowLeftRight className="w-4 h-4 text-slate-400" />
            </h1>
            <p className="text-xs sm:text-sm text-slate-500">
              Select active speaker direction or switch seamlessly during live conversation.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <div className="inline-flex rounded-lg bg-slate-200/80 p-1 text-xs font-semibold">
              <button
                type="button"
                onClick={() => setActiveTab('hearing-to-sign')}
                className={`px-3.5 py-1.5 rounded-md transition-all whitespace-nowrap ${
                  activeTab === 'hearing-to-sign'
                    ? 'bg-white text-indigo-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                1. Hearing Person Speaking
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('sign-to-hearing')}
                className={`px-3.5 py-1.5 rounded-md transition-all whitespace-nowrap ${
                  activeTab === 'sign-to-hearing'
                    ? 'bg-white text-emerald-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                2. ISL User Signing
              </button>
            </div>
          </div>
        </div>

        {/* Active Communication Panel */}
        <div className="transition-all duration-150">
          {activeTab === 'hearing-to-sign' ? (
            <HearingToSign />
          ) : (
            <SignToSpeech />
          )}
        </div>

        {/* Accessibility & Safety Reminder Footer Note */}
        <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700">SAMVAAD</span>
            <span>· Indian Sign Language Communication System</span>
          </div>

          <div className="flex items-center gap-4 text-[11px]">
            <span>Speech: Web Speech API</span>
            <span aria-hidden="true">·</span>
            <span>Vision: Roboflow (isl-words/1)</span>
            <span aria-hidden="true">·</span>
            <span>Database: Supabase (cdnnjivtfzzfihgzlzys)</span>
          </div>
        </div>
      </main>

      {/* 3. Standalone SOS Emergency Modal */}
      <SosModal isOpen={isSosOpen} onClose={() => setIsSosOpen(false)} />

      {/* 4. Supabase SQL & Roboflow Setup Guide Modal */}
      <SetupGuideModal isOpen={isSetupOpen} onClose={() => setIsSetupOpen(false)} />
    </div>
  );
}
