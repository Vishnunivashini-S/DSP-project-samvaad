export interface IslVideo {
  id: string;
  phrase: string;
  keywords: string[];
  description?: string | null;
  video_url: string;
  category?: string | null;
  is_verified: boolean;
  created_at?: string;
  updated_at?: string;
}

export interface PredictionBBox {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface PredictionResult {
  class: string;
  confidence: number;
  bbox?: PredictionBBox;
}

export interface InferenceResponse {
  success?: boolean;
  topPrediction?: PredictionResult | null;
  bestCandidate?: PredictionResult | null;
  allPredictions?: PredictionResult[];
  supportedClasses?: string[];
  thresholdApplied?: number;
  totalPredictions?: number;
  model?: string;
  error?: string;
  details?: string;
  unconfigured?: boolean;
}

export interface EmergencyHotline {
  name: string;
  number: string;
  type: string;
}

export interface SosResponse {
  success: boolean;
  configured: boolean;
  status: 'dispatched' | 'unconfigured' | 'failed';
  provider?: string;
  recipient?: string;
  message: string;
  advice?: string;
  error?: string;
  emergencyHotlines: EmergencyHotline[];
}
