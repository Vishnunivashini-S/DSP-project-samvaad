-- ==============================================================================
-- SAMVAAD — Indian Sign Language Two-Way Communication Database Schema
-- File: supabase/schema.sql
-- Run this script in: Supabase Dashboard -> SQL Editor -> New query -> Run
-- ==============================================================================

-- 1. Create table for verified Indian Sign Language (ISL) demonstration videos
CREATE TABLE IF NOT EXISTS public.isl_videos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    phrase VARCHAR(255) NOT NULL,
    keywords TEXT[] DEFAULT '{}',
    description TEXT,
    video_url TEXT NOT NULL,
    category VARCHAR(100) DEFAULT 'general',
    is_verified BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 2. Performance and lookup indices
-- Case-insensitive B-Tree index for exact phrase matching
CREATE INDEX IF NOT EXISTS idx_isl_videos_phrase_lower 
ON public.isl_videos (LOWER(TRIM(phrase)));

-- GIN index for fast keyword matching and array overlap queries
CREATE INDEX IF NOT EXISTS idx_isl_videos_keywords 
ON public.isl_videos USING GIN (keywords);

-- Partial index for verified active signs (optimized for the public read policy)
CREATE INDEX IF NOT EXISTS idx_isl_videos_verified 
ON public.isl_videos (is_verified) 
WHERE is_verified = true;

-- 3. Row Level Security (RLS)
ALTER TABLE public.isl_videos ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if re-running script to ensure clean setup
DROP POLICY IF EXISTS "Allow unauthenticated read of verified sign videos" ON public.isl_videos;
DROP POLICY IF EXISTS "Prevent public mutation of sign videos" ON public.isl_videos;

-- Public can SELECT ONLY records where is_verified = true
CREATE POLICY "Allow unauthenticated read of verified sign videos"
ON public.isl_videos
FOR SELECT
TO anon, authenticated
USING (is_verified = true);

-- Deny unauthenticated users from inserting, updating, or deleting videos
-- (Only service_role or authenticated admin users can modify videos)
CREATE POLICY "Prevent public insert of sign videos"
ON public.isl_videos
FOR INSERT
TO authenticated
WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Prevent public update of sign videos"
ON public.isl_videos
FOR UPDATE
TO authenticated
USING (auth.role() = 'authenticated');

CREATE POLICY "Prevent public delete of sign videos"
ON public.isl_videos
FOR DELETE
TO authenticated
USING (auth.role() = 'authenticated');

-- 4. Optional SOS Events Audit Table
-- Records emergency alert triggers with timestamp and status
CREATE TABLE IF NOT EXISTS public.sos_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    status VARCHAR(50) NOT NULL, -- 'dispatched', 'unconfigured', 'failed', 'cancelled'
    recipient_type VARCHAR(50) DEFAULT 'emergency_contact',
    provider VARCHAR(50) DEFAULT 'server_backend',
    details JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

ALTER TABLE public.sos_events ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow public insertion of SOS audit events" ON public.sos_events;
DROP POLICY IF EXISTS "Restrict read of SOS audit events" ON public.sos_events;

-- Allow application to record an SOS incident audit log
CREATE POLICY "Allow public insertion of SOS audit events"
ON public.sos_events
FOR INSERT
TO anon, authenticated
WITH CHECK (true);

-- SOS event history is restricted and cannot be read anonymously
CREATE POLICY "Restrict read of SOS audit events"
ON public.sos_events
FOR SELECT
TO authenticated
USING (auth.role() = 'authenticated');

-- 5. Helper search function for phrase and keyword matching
CREATE OR REPLACE FUNCTION public.search_verified_isl_video(search_query TEXT)
RETURNS SETOF public.isl_videos
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    normalized_query TEXT := LOWER(TRIM(search_query));
BEGIN
    -- 1. Exact phrase match first
    RETURN QUERY
    SELECT *
    FROM public.isl_videos
    WHERE is_verified = true
      AND LOWER(TRIM(phrase)) = normalized_query
    LIMIT 1;

    -- If found, exit
    IF FOUND THEN
        RETURN;
    END IF;

    -- 2. Keyword containment match
    RETURN QUERY
    SELECT *
    FROM public.isl_videos
    WHERE is_verified = true
      AND (
        normalized_query = ANY(keywords)
        OR phrase ILIKE '%' || normalized_query || '%'
      )
    LIMIT 1;
END;
$$;

-- 6. Sample Seed Data
-- Note: As per safety specifications, all sample placeholder records are marked
-- is_verified = false. They WILL NOT be displayed to users until you upload
-- real verified Indian Sign Language video files to your Supabase Storage bucket
-- ('isl-videos') and update is_verified to true.

INSERT INTO public.isl_videos (phrase, keywords, description, video_url, category, is_verified)
VALUES
    (
        'Hello', 
        ARRAY['hello', 'hi', 'namaste', 'greetings'], 
        'Open hand moves outwards from forehead/temple in greeting.',
        'https://cdnnjivtfzzfihgzlzys.supabase.co/storage/v1/object/public/isl-videos/sample_hello.mp4', 
        'greetings', 
        false
    ),
    (
        'Thank you', 
        ARRAY['thank', 'thanks', 'gratitude', 'dhanyawad', 'shukriya'], 
        'Fingertips touch chin and extend outward towards the person.',
        'https://cdnnjivtfzzfihgzlzys.supabase.co/storage/v1/object/public/isl-videos/sample_thank_you.mp4', 
        'courtesy', 
        false
    ),
    (
        'Yes', 
        ARRAY['yes', 'haan', 'agree', 'correct', 'true'], 
        'Fist gently nods up and down imitating a head nod.',
        'https://cdnnjivtfzzfihgzlzys.supabase.co/storage/v1/object/public/isl-videos/sample_yes.mp4', 
        'affirmation', 
        false
    ),
    (
        'No', 
        ARRAY['no', 'nahin', 'disagree', 'incorrect', 'false'], 
        'Index and middle finger snap together against the thumb, or index finger wags left to right.',
        'https://cdnnjivtfzzfihgzlzys.supabase.co/storage/v1/object/public/isl-videos/sample_no.mp4', 
        'negation', 
        false
    ),
    (
        'Please', 
        ARRAY['please', 'kripya', 'request', 'kindly'], 
        'Flat palm rubs in a gentle circular motion over the center of the chest.',
        'https://cdnnjivtfzzfihgzlzys.supabase.co/storage/v1/object/public/isl-videos/sample_please.mp4', 
        'courtesy', 
        false
    )
ON CONFLICT DO NOTHING;
